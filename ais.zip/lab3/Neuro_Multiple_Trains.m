Read_PT;

result = zeros(3, 4);
times = zeros(1, 7);
diff = zeros(1, 7);

for i = 1:7
    net = newff(P, T, [8 10], {'logsig','tansig'});
    net.trainFcn='trainoss';

    net.performFcn = 'mse';
    net.trainParam.epochs = 1500;
    net.trainParam.goal = 1E-4;
    net.trainParam.time = 5 * 60;
    net.trainParam.max_fail = 10;
    net.divideFcn = '';
    
    [net, tr] = train(net, P, T, [], [], [], []);
    times(i) = tr.time(end);
end

tc = (1. / 7) * sum(times);
for i = 1:7
    diff(i) = (times(i) - tc) * (times(i) - tc);
end
sg = sqrt((1. / 7) * sum(diff));
s = sqrt(7. / 6) * sg;
del = 2.45 * s / sqrt(7);
m1 = 2.45 * 2.45 * s * s / 0.01;
result(1, :) = [tc, sg, del, m1];


for i = 1:7
    net = newff(P, T, [8 10], {'logsig','tansig'});
    net.trainFcn='trainoss';

    net.performFcn = 'mse';
    net.trainParam.epochs = 1500;
    net.trainParam.goal = 1E-4;
    net.trainParam.time = 5 * 60;
    net.trainParam.max_fail = 10;
    net.divideFcn = '';
    
    [net, tr] = train(net, P, T, [], [], [], []);
    times(i) = tr.time(end);
end

tc = (1. / 7) * sum(times);
for i = 1:7
    diff(i) = (times(i) - tc) * (times(i) - tc);
end
sg = sqrt((1. / 7) * sum(diff));
s = sqrt(7. / 6) * sg;
del = 2.45 * s / sqrt(7);
m1 = 2.45 * 2.45 * s * s / 0.01;
result(2, :) = [tc, sg, del, m1];


for i = 1:7
    net = newff(P, T, [8 10], {'logsig','tansig'});
    net.trainFcn='trainoss';

    net.performFcn = 'mse';
    net.trainParam.epochs = 1500;
    net.trainParam.goal = 1E-4;
    net.trainParam.time = 5 * 60;
    net.trainParam.max_fail = 10;
    net.divideFcn = '';
    
    [net, tr] = train(net, P, T, [], [], [], []);
    times(i) = tr.time(end);
end

tc = (1./7)*sum(times);
for i = 1:7
    diff(i) = (times(i) - tc) * (times(i) - tc);
end
sg = sqrt((1. / 7) * sum(diff));
s = sqrt(7. / 6) * sg;
del = 2.45 * s / sqrt(7);
m1 = 2.45 * 2.45 * s * s / 0.01;
result(3, :) = [tc, sg, del, m1];

disp('Час навчання Стандартне відхилення  Довірчий інтервал Дисперсія');
disp('--------------------------------------');
for i = 1:size(result, 1)
    fprintf('%0.4f      %0.4f      %0.4f      %0.4f\n', result(i,:));
end

save('multiple_trains');