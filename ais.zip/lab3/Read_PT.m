class_mapping = importdata("Neuro_Data\Neuro_Train\Class_Name_ty1.txt");
image_mapping = importdata("Neuro_Data\Neuro_Train\File_Name_tx1.txt");

num_images = numel(image_mapping);


P = zeros(16 * 16, num_images);
T = zeros(4, num_images);

for i = 1:num_images

    temp = strsplit(image_mapping{i, 1}, " ");
   
    classnum = str2double(temp(1));
    filename_no_ext = temp(2);
    
    filename = strcat("Neuro_Data\Neuro_Train\", filename_no_ext, '.bmp');

    img = imread(filename);
    gray_img = rgb2gray(img);
    gray_img_col = reshape(gray_img, [], 1);
    
    P(:, i) = gray_img_col;

    T(classnum, i) = 1;
end