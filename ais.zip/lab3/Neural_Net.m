class_mapping = importdata("Neuro_Data\Neuro_Train\Class_Name_ty1.txt");

file = "Networks\CharNetwork.mat";
load(file, 'net', 'tr');

image_filenames = dir("Neuro_Data\Neuro_Recogn\*.bmp");

result_matrix = cell(3 * numel(image_filenames), numel(class_mapping));

for i = 1:numel(image_filenames)

    img = imread( ...
        strcat("Neuro_Data\Neuro_Recogn\", image_filenames(i).name) ...
    );
    gray_img = rgb2gray(img);
    input_vector = double(gray_img(:));
  
    output_vector = sim(net, input_vector);

    [max_val, max_idx] = max(output_vector);

    temp = strsplit(class_mapping{max_idx, 1}, " ");

    result_matrix(3 * i, 1) = cellstr("#");
    result_matrix(3 * i, 2) = cellstr(num2str(i));

    for j=1:numel(output_vector')

        result_matrix(3 * i + 1, j) = cellstr(num2str(output_vector(j)));
    end

    result_matrix(3 * i + 2, 1) = cellstr('most likely');
    result_matrix(3 * i + 2, 2) = cellstr(temp(2));
    result_matrix(3 * i + 2, 3) = cellstr('actual');
    result_matrix(3 * i + 2, 4) = cellstr(image_filenames(i).name(1));
end

disp(tr.time);

writecell(result_matrix, strcat(strrep(file, '.', '_'), '.xlsx'), "FileType","spreadsheet","UseExcel", true);