Read_PT;

net = newff(P, T, [8 10], {'logsig','tansig'});

net.trainFcn='trainoss';

net.performFcn = 'mse';
net.trainParam.epochs = 1500;
net.trainParam.goal = 1E-4;
net.trainParam.time = 5 * 60;
net.trainParam.max_fail = 10;
net.divideFcn = '';

[net, tr] = train(net, P, T, [], [], [], []);
ep1 = tr.epoch;
mse1 = tr.perf;

disp(ep1);
disp(mse1);

save("Networks\CharNetwork.mat")