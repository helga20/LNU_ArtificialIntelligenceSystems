%Вхідні змінні:
% Величина цін (менше значення - гірша ціна)
prices = 5;
% Наявність рецепту на всі пункти (0 - на жоден, 1 - деякі, 2 - на всі)
recipe = 1;

% Нечіткі множини:
% Для цін:
prices_too_high = trapmf(prices, [1 2 4 5]);
prices_moderate = trapmf(prices, [4 5 7 8]);
prices_low = trapmf(prices, [7 8 9 10]);
% Для рецепту:
no_recipe = trapmf(recipe, [0 0 1 1]);
is_recipe = trapmf(recipe, [1 1.5 1.5 2]);
% Для задоволеністю покупкою:
bad_purchase = trapmf(0:0.1:5, [0 0 1.5 2.5]);
norm_purchase = trapmf(0:0.1:5, [1.5 2.5 3.5 4.5]);
good_purchase = trapmf(0:0.1:5, [3.5 4.5 5 5]);

% Правила для нечітких множин:
% Правило №1: Якщо ціни надто високі, але наявний рецепт, то задоволення
% покупкою низьке.
rule1 = min(prices_too_high, is_recipe);
satisfaction_rule1 = bad_purchase;
% Правило №2: Якщо ціни надто високі, але наявний рецепт, то задоволення
% покупкою відсутнє.
rule2 = min(prices_too_high, no_recipe);
satisfaction_rule2 = bad_purchase;
% Правило №3: Якщо ціни нормальні і наявний рецепт, то задоволення
% покупкою середнє.
rule3 = min(prices_moderate, is_recipe);
satisfaction_rule3 = norm_purchase;
% Правило №4: Якщо ціни нормальні, але нема рецепту, то задоволення
% покупкою середнє.
rule4 = min(prices_moderate, no_recipe);
satisfaction_rule4 = norm_purchase;
% Правило №5: Якщо ціни низькі і нема рецепту, то задоволення
% покупкою середнє.
rule5 = min(prices_moderate, no_recipe);
satisfaction_rule5 = norm_purchase;
% Правило №6: Якщо ціни низькі і наявний рецепт, то задоволення
% покупкою високе.
rule6 = min(prices_low, no_recipe);
satisfaction_rule6 = good_purchase;

% Об'єднання множин:
res_union = max([rule1; rule2; rule3; rule4; rule5; rule6]);
res = sum(res_union .*(0:0.1:1)) / sum(res_union);
% Результат:
fprintf('Задоволення покупкою: %.2f\n', res);